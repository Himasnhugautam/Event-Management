module EventManagementSystem {
	requires java.sql;
}