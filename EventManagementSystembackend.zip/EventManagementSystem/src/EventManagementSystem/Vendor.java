package EventManagementSystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Vendor {
private Connection connection;
	
	//private Scanner scanner;
	
	public Vendor(Connection connection) {
	this.connection=connection;
	//this.scanner=scanner;
	
	}
		public void viewVendor() {
		String query ="select * from vendor";
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultSet= preparedStatement.executeQuery();
		    System.out.println("vendor: ");
		    System.out.println("+------------+--------------------+------------------+");
		    System.out.println("| Vendor ID  | Name               | phonenumber      |");
		    System.out.println("+------------+--------------------+------------------+");
			while(resultSet.next()) {
				int id = resultSet.getInt("id");
				String name = resultSet.getString("name");
				
				int phonenumber = resultSet.getInt("phonenumber");
				
				
				System.out.printf("|%-12s|%-20s|%-18s|\n", id, name, phonenumber);
				System.out.println("+------------+--------------------+------------------+");
				
			}
	}catch (SQLException e) {
		e.printStackTrace();
		
	}
	}
	public boolean getVendorById(int id) {
		String query= "Select * from vendor where id =?";
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt (1,id);
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {
				return true;
			}
			else {
				return false;
			}
			
			}catch (SQLException e) {
				e.printStackTrace();
				
			
			
		}
		return false;
	}

}



