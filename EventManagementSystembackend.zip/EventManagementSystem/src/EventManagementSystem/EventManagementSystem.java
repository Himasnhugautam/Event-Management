package EventManagementSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class EventManagementSystem {
	private static final String url="jdbc:mysql://localhost:3306/hospital";
	private static final String username ="root";
	private static final String password = "HimGau704@";
	@SuppressWarnings("null")
	private static final short EventId = (Short) null;
	private static int vendorId;
	private static String Date;
	private static String bookQuery;
	private static String bookDate;
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver" );
		    
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
			
		}
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		try {
			Connection connection = DriverManager.getConnection(url,username,password);
			@SuppressWarnings("unused")
			Event event = new Event(connection, scanner);
			@SuppressWarnings("unused")
			Vendor vendor = new Vendor(connection);
			while(true) {
				System.out.println("HOSPITAL MANAGEMENT STSYTEM");
				System.out.println("1. Add Member");
				System.out.println("2. View Member");
				System.out.println("3. View Vendor");
				System.out.println("4. Book Event");
				System.out.println("5. Exit");
				System.out.println("Enter your choice");
				int Choice = scanner.nextInt();
				
				switch(Choice) {
				case 1:
				
				event.addMember();
				System.out.println();
				break;
				
				case 2:
				
				event.viewMember();
				System.out.println();
				break;
				
				
				case 3:
				// View Doctors
				vendor.viewVendor();
				System.out.println();
				break;
				
				
				case 4:
				 bookAppointment(event,vendor,connection,scanner);
					System.out.println();
					break;
				case 5:
					System.out.println("Thank you for using Event Management System");
				return;
				default:
					System.out.println("Enter valid Choice!!");
					break;
				
				}
			}
		}catch(SQLException e) {
			e.printStackTrace();
			
		}
		
	}
	public static void bookAppointment(Event event, Vendor vendor, Connection connection, Scanner scanner) {
		System.out.print("Enter Event Id:");
		int PatientId=scanner.nextInt();
		System.out.print("enter Vendor Id:");
		int doctorId = scanner.nextInt();
		System.out.print("Enter  date(YYYY-MM-DD):");
		String appointmentDate = scanner.next();
		if(event.getEventById(EventId)&& vendor.getVendorById(vendorId)) 
		{
			if(checkDoctorAvailability(doctorId, bookDate ,connection))
			{
				String appointmentQuery= "INSERT INTO appointments(patient_id, doctor_id, appointment_date) VALUES(?,?,?)";
				try {
					PreparedStatement preparedStatement = connection.prepareStatement(bookQuery);
					preparedStatement.setShort(1,EventId);
					preparedStatement.setInt(2,vendorId);
					preparedStatement.setString(3,Date);
					int rowsAffected = preparedStatement.executeUpdate();
					if(rowsAffected>0) {
						System.out.println(" Booked!");
						
					}else {
						System.out.println("Failed to Book !");
					}
					
					
					
				}catch (SQLException e) {
					e.printStackTrace();
				}
			
			}else {
				System.out.println("vendor not available on this date");
			}
			
		}else {
			System.out.println("Either member or vendor doesn't exist!!!");
		}
		
	}
	public static boolean checkDoctorAvailability(int vendorId, String bookDate, Connection connection) {
		
	String query= "SELECT COUNT(*) FROM event WHERE vendor_id=? AND book_date =?";
	try {
		PreparedStatement preparedStatement = connection.prepareStatement(query);
		preparedStatement.setInt(1,vendorId);
		preparedStatement.setString(2, bookDate);
		ResultSet resultSet = preparedStatement.executeQuery();
		if(resultSet.next()) {
			int count = resultSet.getInt(1);
			if(count==0) {
				return true;
				
			}else {
				return false;
				 
			}
		}
		
		
		
	}catch (SQLException e) {
		e.printStackTrace();
	}
	return false;
	
}

}



